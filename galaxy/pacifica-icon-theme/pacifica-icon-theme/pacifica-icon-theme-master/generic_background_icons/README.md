###Contribute

Here you have 3 generic background icons that I use on Pacifica Icon Theme.

If you want to contribute, send me your icons to my email fsvh@me.com and I will add to the pack. It will add your name to the CREDIT text file and the name of each icon with which you contributed.

I'll try to make an update every week but for now I'm with a lot of work.

Thanks for your help.

Regards.

